CREATE TABLE 뉴스(
	종목코드 INT NOT NULL,
    뉴스제목 VARCHAR(100) NOT NULL,
    뉴스요약 mediumtext NOT NULL,
    뉴스이미지 VARCHAR(200),
    뉴스url VARCHAR(200) NOT NULL,
    primary key(종목코드, 뉴스url),
    Foreign key (종목코드) references 종목코드(종목코드)
);