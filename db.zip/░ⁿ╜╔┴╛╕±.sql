CREATE TABLE 관심종목(
	ID VARCHAR(20) NOT NULL,
    종목코드 INT NOT NULL,
    primary key(ID, 종목코드),
    Foreign key (종목코드) references 종목코드(종목코드),
    Foreign key (ID) references 사용자(ID)
);