CREATE TABLE 보유주식(
	ID VARCHAR(20) NOT NULL,
    종목코드 INT NOT NULL,
    주식수 INT NOT NULL,
    매도가 INT NOT NULL,
    매도일 DATE NOT NULL,
    primary key(ID, 종목코드, 매도가, 매도일),
    Foreign key (종목코드) references 종목코드(종목코드),
    Foreign key (ID) references 사용자(ID)
);