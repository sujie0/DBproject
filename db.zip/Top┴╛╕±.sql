CREATE TABLE Top종목(
	종목코드 INT NOT NULL,
    거래량 INT NOT NULL DEFAULT 0,
    상승률 INT NOT NULL DEFAULT 0,
    하락률 INT NOT NULL DEFAULT 0,
    primary key(종목코드),
    Foreign key (종목코드) references 종목코드(종목코드)
);