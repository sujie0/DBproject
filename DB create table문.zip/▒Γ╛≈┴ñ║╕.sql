CREATE TABLE 기업정보(
	종목코드 INT NOT NULL PRIMARY KEY,
    기업이름 VARCHAR(45) NOT NULL,
    상장주식수 INT NOT NULL,
    기업개요 VARCHAR(200) NOT NULL,
    Foreign key (종목코드) references 종목코드(종목코드)
);