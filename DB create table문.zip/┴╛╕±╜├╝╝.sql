CREATE TABLE 종목시세(
	종목코드 INT NOT NULL,
    날짜 DATE NOT NULL,
    시가 INT NOT NULL,
    저가 INT NOT NULL,
    고가 INT NOT NULL,
    종가 INT NOT NULL,
    거래량 INT NOT NULL,
    차트 VARCHAR(200),
    primary key(종목코드, 날짜),
    Foreign key (종목코드) references 종목코드(종목코드)
);