CREATE TABLE 주주현황(
	종목코드 INT NOT NULL,
    주요주주 VARCHAR(100) NOT NULL,
    보유주식수 INT NOT NULL,
    보유지분 FLOAT NOT NULL,
    primary key(종목코드, 주요주주),
    Foreign key (종목코드) references 종목코드(종목코드)
);