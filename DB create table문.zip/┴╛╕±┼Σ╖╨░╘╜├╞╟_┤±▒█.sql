CREATE TABLE 종목토론게시판_댓글(
	idx INT UNSIGNED NOT NULL AUTO_INCREMENT,
    게시판idx INT UNSIGNED NOT NULL,
	ID VARCHAR(20) NOT NULL,
	댓글 VARCHAR(200) NOT NULL,
	primary key(idx),
    Foreign key (ID) references 사용자(ID),
    Foreign key (게시판idx) references 종목토론게시판(idx)
);