CREATE TABLE 종목토론게시판(
	idx INT UNSIGNED NOT NULL AUTO_INCREMENT,
    ID VARCHAR(20) NOT NULL,
    글제목 VARCHAR(100) NOT NULL,
    글내용 mediumtext NOT NULL,
    이미지 VARCHAR(200),
    신고횟수 INT DEFAULT 0,
    primary key(idx),
    Foreign key (ID) references 사용자(ID)
);
    